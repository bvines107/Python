
numbers = [1, 2, 3, 4, 3]


#answer function that accepts an array
def answers(numbers):
    #initializes the while loop
    i = 0
    #stores the length of the array
    n = len(numbers)

    try:
        #if statement to check if the array length is greater than 2 but less than 5000
        if n >= 2 & n <= 5000:

             # loops through the array
            while i in range(0, n - 1):
                if numbers[0] > len(numbers):
                    print("An Error Occured, Array index out of bounds.")
                    break
                else:
                    i = numbers[i]
                    i += 1
                    #prints the output.
                    return "The program looped " + str(i) + " times"
    except ValueError:
        print("An Error Occured")

# call to the answer function
print(answers(numbers))




























