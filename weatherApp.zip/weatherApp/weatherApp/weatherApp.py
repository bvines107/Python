from pickle import FALSE
from bs4 import BeautifulSoup as bs
import requests
from tkinter import Label
from tkinter import Tk
from PIL import ImageTk, Image


url = 'https://weather.com/weather/today/l/b7ba675714c6e43bd6f0c54c169f0fb4ff9117528a444ce90a5588ca347b1f027dad8528810451f9d267a388d52a5061'

master = Tk()
master.title("Weather App")
master.config(bg= 'white')

img = Image.open('images.png')
img = img.resize((150,150))
img = ImageTk.PhotoImage(img)

def getWeather():
    page = requests.get(url, verify=False)
    soup = bs(page.content, 'html.parser')
    location = soup.find('h1', class_='CurrentConditions--location--kyTeL').text
    temperature = soup.find('span', class_='CurrentConditions--tempValue--3a50n').text
    weatherPrediction = soup.find('div', class_='CurrentConditions--phraseValue--2Z18W').text
    

    locationlabel.config(text=location)
    temperaturelabel.config(text=temperature)
    weatherPredictionLabel.config(text=weatherPrediction)


locationlabel = Label(master, font=("Calibri bold",20), bg="white")
locationlabel.grid(row=0, sticky="n",padx=100)

temperaturelabel = Label(master, font=("Calibri bold",70), bg="white")
temperaturelabel.grid(row=1, sticky="W",padx=50)

Label(master, image=img, bg='white').grid(row=1,sticky='E')

weatherPredictionLabel = Label(master, font=('Calibri bold', 15), bg='white')
weatherPredictionLabel.grid(row=2, sticky='w', padx=30)


getWeather()
master.mainloop()




