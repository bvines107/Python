import random  # gives you access to generate random numbers


# game introduction
print("***********Welcome to the Dice Game********************")


# roll function to take user input, roll dice, and play again
def roll():
    # take in the user input, converts it into an int, stores it in the num variable
    num = int(input("Pick a number between 2 and 12 "))
    print()
    print("Rolling the dice.............")
    # simulates a dice being rolled twice by adding the numbers together and storing them in the ro1 variable
    ro1 = random.randint(1, 6) + random.randint(1, 6)
    # prints the 1st roll
    print(ro1)

    # simulates the user's second roll dice being rolled twice by adding the numbers together
    # and storing them in the ro2 variable
    ro2 = random.randint(1, 6) + random.randint(1, 6)
    # prints the 2nd roll
    print(ro2)

    # simulates a dice being rolled twice by adding the numbers together and storing them in the ro3 variable
    ro3 = random.randint(1, 6) + random.randint(1, 6)
    # prints the 3rd roll
    print(ro3)

    # if statement to determine if the user one. if the user is equal to the same as ro1, ro2 or ro3 they win
    if num == ro1 or num == ro2 or num == ro3:
        print("You won by rolling: ", num)
    else:
        print("You lost!")

    # asks the user if they would like to play again, stores input in again variable
    again = input("Would you like to play again? y = yes").lower()
    # if yes program restarts, converts input to str
    if again == str("y" or "yes"):
        roll()
    else:
        print("Thank you for playing: Goodbye!")


# calls the roll function
roll()

